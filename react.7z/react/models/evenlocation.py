from postgres import ext_base
from sqlalchemy import String, Integer, Timestamp, Boolean, text

class DB_QUERY(ext_base):
    __tablename__ = "eventLocation"
    
    ID = (Integer, primary_key='True', nullable='False' )
    eventName = (String, nullable='False')
    Location = (String, nullable='False')
    Time = (String, Timestamp)
    user = (String nullable='False')
    
