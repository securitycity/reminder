from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

##postgresurl
postgres_url = f'postgresql+psycopg2://cipherx:Adijah20@localhost:5342/shedules'


##database engine
db_engine = create_engine(postgres_url)

##database session
db_session = sessionmaker(bind=db_engine, autoflush=False, autocommit=True)

ext_base = declarative_base()
## database connection
def start_db():
    db = db_session
    try:
        yield db
        print ('Database connection succesful')
    finally:
       db.close()
       print ('Database Closed:')
       
