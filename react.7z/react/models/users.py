from postgres import ext_base, db_engine
from sqlalchemy import String, Integer, TIMESTAMP, Boolean, text, Column

class UserQUERY(ext_base):
    __tablename__ = "Users"
    
    ID = Column(Integer, primary_key='True', nullable='False' )
    UserName = Column(String, nullable='False')
    password = Column(String,nullable='False')
    Location = Column(String, nullable='False')
    Time = Column(TIMESTAMP(timezone='True'), server_default=text( 'now()'))
    
    

db_conn = ext_base.metadata.create_all(bind=db_engine)

print(db_conn)
