## check if a service is running and start it
##networking...
$service = Get-service -Name "NetSetupSvc", "Netman"

if ($service.status -ne "Running") {
	Start-Service -Name "NetSetupSvc", "Netman"
	write-host "Services Netman and NetSetupSvc Started"
} else{
	write-host "Services Netman and NetSetupSvc not Started"
}

