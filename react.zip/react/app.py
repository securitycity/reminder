from fastapi import FastAPI
from strawberry.fastapi import GraphQLRouter
import schemas.schema

app = FastAPI()

@app.get("/")
def read_root():
    return{"Welcome to fastapi"}
    
    
schema = schemas.schema
graphqlapp = GraphQLRouter(schema)
app.include_router(graphqlapp, prefix="/graphql")

