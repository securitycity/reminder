# Allow PostgreSQL TCP connections via PowerShell
# Tested on PostgreSQL 13–16 (Windows)

# --- CONFIGURATION ---
$pgDataDir = "C:\Program Files\PostgreSQL\16\data"  # Path to PostgreSQL data directory
$listenAddress = "*"                               # Listen on all interfaces
$allowedCIDR = "0.0.0.0/0"                         # Allow all IPs (change for security)
$pgServiceName = "postgresql-x64-16"                # PostgreSQL Windows service name
$AllowedIPADDR = "127.0.0.1, 192.168.100.52"



# --- VALIDATION ---
if (-not (Test-Path $pgDataDir)) {
    Write-Error "PostgreSQL data directory not found: $pgDataDir"
    exit 1
}

# --- Update postgresql.conf ---
$pgConfFile = Join-Path $pgDataDir "postgresql.conf"
if (-not (Test-Path $pgConfFile)) {
    Write-Error "postgresql.conf not found in $pgDataDir"
    exit 1
}

# Backup original file
Copy-Item $pgConfFile "$pgConfFile.bak" -Force

# Enable listen_addresses
(Get-Content $pgConfFile) |
    ForEach-Object {
        if ($_ -match "^\s*#?\s*listen_addresses\s*=") {
            "listen_addresses = '$listenAddress'"
        } else {
            $_
        }
    } | Set-Content $pgConfFile -Encoding UTF8

Write-Host "Updated listen_addresses in postgresql.conf"

# --- Update pg_hba.conf ---
$pgHbaFile = Join-Path $pgDataDir "pg_hba.conf"
if (-not (Test-Path $pgHbaFile)) {
    Write-Error "pg_hba.conf not found in $pgDataDir"
    exit 1
}

# Backup original file
Copy-Item $pgHbaFile "$pgHbaFile.bak" -Force

# Add host rule if not already present
$rule = "host    all             all             $allowedCIDR            md5"
if (-not (Select-String -Path $pgHbaFile -Pattern [regex]::Escape($rule))) {
    Add-Content $pgHbaFile "`n$rule"
    Write-Host "Added TCP access rule to pg_hba.conf"
} else {
    Write-Host "TCP access rule already exists in pg_hba.conf"
}

# --- Restart PostgreSQL service ---
try {
    Restart-Service -Name $pgServiceName -Force -ErrorAction Stop
    Write-Host "PostgreSQL service restarted successfully."
} catch {
    Write-Error "Failed to restart PostgreSQL service: $_"
}

Write-Host "PostgreSQL is now configured to allow TCP connections."
