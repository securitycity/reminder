from postgres import ext_base
from sqlalchemy import String, Integer, Timestamp, Boolean, text

class DB_QUERY(ext_base):
    __tablename__ = "Events"
    
    ID = (Integer, primary_key='True', nullable='False' )
    User = (String, nullable='False')
    Location = (String, nullable='False')
    event = (String, nullable='False')
    Time = (String, Timestamp)
    
