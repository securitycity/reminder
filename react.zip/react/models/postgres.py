from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base


##postgresurl
postgres_url = f'postgresql+psycopg2://cipherx:Adijah20@127.0.0.1:5432/shedules'


##database engine
db_engine = create_engine(postgres_url)

##database session
db_session = sessionmaker(bind=db_engine, autoflush=False, autocommit=True)

ExtBase = declarative_base
    
## database connection
def start_db():
    db = db_session
    try:
        yield db
        print ('Database connection succesful')
    finally:
       db.close()
       print ('Database Closed:')
       
start_db()
