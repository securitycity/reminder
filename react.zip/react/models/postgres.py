from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase


##postgresurl
postgres_url = f'postgresql+psycopg2://cipherx:Adijah20@192.168.100.54:5432/shedules'


##database engine
db_engine = create_engine(postgres_url)

##database session
db_session = sessionmaker(bind=db_engine, autoflush=False, autocommit=True)

class ExtBase(DeclarativeBase):
    pass
    
## database connection
def start_db():
    db = db_session
    try:
        yield db
        print ('Database connection succesful')
    finally:
       db.close()
       print ('Database Closed:')
       
start_db()
