from postgres import ExtBase, db_engine
from sqlalchemy import TIMESTAMP, func
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime

class DB_QUERY(ExtBase):
    __tablename__ = "Events"
    
    id: Mapped[int]= mapped_column(primary_key=True, autoincrement=True, nullable=False )
    user: Mapped[str] = mapped_column(nullable=False)
    Location: Mapped[str] = mapped_column(nullable=False)
    event: Mapped[str] = mapped_column(nullable=False)
    time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    
try:
    eventsdb = ExtBase.metadata.create_all(bind=db_engine)
    print(f'Query successful: {eventsdb}')
except Exception as e:
    print(e)