from postgres import ExtBase, db_engine
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import func, TIMESTAMP
from datetime import datetime

class UserQUERY(ExtBase):
    __tablename__ = "Users"
    
    ID: Mapped[int] = mapped_column(primary_key=True, autoincrement=True, nullable=False )
    UserName: Mapped[str] = mapped_column(nullable=False)
    password: Mapped[str] = mapped_column(nullable=False)
    Location: Mapped[str] = mapped_column(nullable=False)
    Time: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    
    
try:
    db_conn = ExtBase.metadata.create_all(bind=db_engine)
    print(f'User Query successful{db_conn}')
except Exception as e:
    print(e)
