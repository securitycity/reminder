import strawberry
from models.users import UserQuery as UserModel
from postgres import get_db
from typing import List

@strawberry.field
##query all available users

users = [[dennis, Adijah20, Nairobi], [Eric, ericsonx20, Nyeri], [Brian, Bree420, Nairobi]]

async def get_users() -> List[UserQuery]:
    async with get_db as session:
        result = await session.execute(select(UserModel))
        return result.scalars().all()


       
##fetching available events

#@strawberry.fields
#async def get_events(self) -> List[Events]