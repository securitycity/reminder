$httplistener = New-Object System.Net.HttpListener
$httplistener.Prefixes.Add("http://192.168.100.54:8080/")
$httplistener.Start()