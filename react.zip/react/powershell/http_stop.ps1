$httplistener.Stop()
