from typing import List
import strawberry, os, sys

model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models'))

if model_path not in sys.path:
    sys.path.insert(0, model_path)

import events as eventmodel

@strawberry.type    
class Event:
    id: int
    eventname: str
    eventlocation: str
    user: List[User]
    eventtime: str


@strawberry.type
class Query:
    @strawberry.filed
    @staticmethod
    def get_event(parent: strawberry.parent[Event]) -> str:
        try:
            event = eventmodel.object.first()
            print (f'Event Object Subscriptable[+]')
            return event
        except Exception as e:
            print(f'Object not subscriptible[-]')
            pass
 
@strawberry.type
class Mutation:
    def addevent(self, eventname: str, eventlocation: str, user: str, eventtime: str) -> Event:
        return Event(eventname=eventname, eventlocation=eventlocation, user=user, eventtime=eventtime)


try:
    schema = strawberry.schema(query=Query, mutation=Mutation
    print(f'Schema created: {schema}')

except Exception as e:
    print(f'Caught error: {e}')
    
