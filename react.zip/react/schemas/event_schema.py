from typing import List
import strawberry, os, sys

model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'models'))

if model_path not in sys.path:
    sys.path.insert(0, model_path)

import events as eventmodel

@strawberry.type    
class Event:
    id: int
    event_name: str
    event_location: str
    user: List[User]
    time: str


@strawberry.type
class Query:
    @strawberry.filed
    @staticmethod
    def get_event(parent: strawberry.parent[Event]) -> str:
        event = eventmodel.object.first()
        return event
 