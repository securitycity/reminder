from typing import List
import strawberry, os, sys


##use relative path
model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', "models"))

if model_path not in sys.path:
    sys.path.insert(0, model_path)

import users as user_model
@strawberry.type
class User:
    id: int
    username: str
    password: str
    location: str

    
@strawberry.type
class Query:
    @strawberry.field
    @staticmethod
    def get_user(parent: strawberry.parent[User])-> str:
        user = user_model.objects.first()

