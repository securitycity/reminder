from typing import List
import strawberry, os, sys


##use relative path
model_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', "models"))

if model_path not in sys.path:
    sys.path.insert(0, model_path)

import users as user_model
@strawberry.type
class User:
    id: int
    username: str
    password: str
    location: str
    event: str

    
@strawberry.type
class Query:
    @strawberry.field
    @staticmethod
    def get_user(parent: strawberry.parent[User])-> str:
        try:
            user = user_model.objects.first()
            print(f'Object Subscriptible[+]')
            return user
            
        except Exception as e:
            print(f'Object NOT subscriptible[-]')
            pass


@strawberry.type
class Mutation:
    @strawberry.mutation
    def adduser(self, id: int, username: str, password: str, location: str, event: str) -> User:
        return User(id: int, username: str, password: str, location: str, event: str)

try:
    schema = strawberry.schema(query=Query, Mutation=mutation)
    print(f'Schema created: {schema}')

except Exception as e:
    print(f'caught error: {e}')
    
