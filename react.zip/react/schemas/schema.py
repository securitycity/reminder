from typing import List
import strawberry


users = [['dennis', 'Adijah20', 'Nairobi'], ['Eric', 'ericsonx20', 'Nyeri'], ['Brian', 'Bree420', 'Nairobi']]

        
@strawberry.type
class User:
    id: int
    username: str
    password: str
    location: str
    
    @strawberry.field
    def user_info(self) ->  str:
        return f"{self.username}, {self.password}, {self.location}"
        

@strawberry.type    
class Event:
    id: int
    event_name: str
    event_location: str
    user: List[User]
    time: str
    
@strawberry.type
class Query:
    @strawberry.field
    def get_user(self)-> str:
        user1 = users[0]
        name = user1[0]
        passwordd = user1[1]
        locationn = user1[2]
        return User(username=name, password=passwordd, location=locationn)
        
@strawberry.type
class Query:
    @strawberry.filed
    def get_event(self) -> str:
        return(Event)